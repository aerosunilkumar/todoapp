import { Component, OnInit, ViewChild } from "@angular/core";
import { MatTableDataSource } from "@angular/material/table";
import { MatPaginator } from "@angular/material/paginator";
import { Todo } from "../todo-service/todo";
import { TodoService } from "../todo-service/todo.service";

@Component({
  selector: "app-todo-list",
  templateUrl: "./todo-list.component.html",
  styleUrls: ["./todo-list.component.scss"]
})
export class TodoListComponent implements OnInit {
  constructor(private todoService: TodoService) {}
  displayedColumns: string[] = ["taskTitle", "taskDueDate", "status", "action"];

  dataSource = new MatTableDataSource<Todo>([]);
  isDataLoading = false;

  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;

  ngOnInit() {
    this.todoService.getAllTodosFromServer();
    this.todoService.isDataLoading.subscribe(val => {
      this.isDataLoading = true;
      this.refreshGrid();
      this.isDataLoading = false;
    });
  }

  completeTask(todo: any) {
    todo.completed = true;
    this.todoService.editTodoTask(
      todo,
      () => {},
      () => {}
    );
  }

  deleteTask(todo: any) {
    this.todoService.deleteTodoTask(
      todo,
      () => {},
      () => {}
    );
  }

  getPriorityClass(todo: any) {
    var today = new Date();
    var taskDueDate = new Date(todo.taskDueDate);
    if (todo.completed) {
      return "alert-success";
    } else if (
      taskDueDate.getDate() == today.getDate() &&
      taskDueDate.getMonth() == today.getMonth() &&
      taskDueDate.getFullYear() == today.getFullYear()
    ) {
      return "alert-warning";
    } else if (taskDueDate < today) {
      return "alert-danger";
    } else {
      return "alert-primary";
    }
  }

  getTaskStatus(todo: any) {
    var today = new Date();
    var taskDueDate = new Date(todo.taskDueDate);
    if (todo.completed) {
      return "Completed";
    } else if (
      taskDueDate.getDate() == today.getDate() &&
      taskDueDate.getMonth() == today.getMonth() &&
      taskDueDate.getFullYear() == today.getFullYear()
    ) {
      return "Medium";
    } else if (taskDueDate < today) {
      return "High";
    } else {
      return "Low";
    }
  }

  refreshGrid() {
    this.dataSource = this.todoService.dataSource;
    this.dataSource.paginator = this.paginator;
  }
}
