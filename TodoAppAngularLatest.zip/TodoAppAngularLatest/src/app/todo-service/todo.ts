export class Todo {
  id: any;
  status: string;
  completed: boolean;
  editing: boolean;
  private _taskDueDate: string;
  get taskDueDate() {
    return this._taskDueDate;
  }
  set taskDueDate(value: string) {
    this._taskDueDate = value;
  }

  private _taskTitle: string;
  get taskTitle() {
    return this._taskTitle;
  }
  set taskTitle(value: string) {
    this._taskTitle = value.trim();
  }

  // private _title: string;
  // get title() {
  // 	return this._title;
  // }
  // set title(value: string) {
  // 	this._title = value.trim();
  // }

  constructor(taskTitle: string, taskDueDate: string) {
    this.completed = false;
    this.editing = false;
    this.taskTitle = taskTitle;
    this.taskDueDate = taskDueDate;
  }
}
