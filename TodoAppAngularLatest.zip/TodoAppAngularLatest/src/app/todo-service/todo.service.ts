import { Injectable } from "@angular/core";
import { Router } from "@angular/router";
import { BehaviorSubject } from "rxjs";
import { Todo } from "./todo";
import { HttpClient } from "@angular/common/http";
import { tap } from "rxjs/operators";
import { MatTableDataSource } from "@angular/material/table";

@Injectable()
export class TodoService {
  baseUrl = "http://localhost:3000";
  constructor(private httpClient: HttpClient) {}
  todos: Todo[] = [];
  isDataLoading = new BehaviorSubject(false);
  dataSource = new MatTableDataSource<Todo>(this.todos);
  getAllTodosFromServer() {
    let todos: any;
    this.isDataLoading.next(true);
    this.httpClient.get(this.baseUrl + "/tasks").subscribe(
      (res: Todo[]) => {
        res.forEach(todo => {
          todo.status = "";
        });
        this.todos = res;
        this.sortByHighToLowPriority();
        this.dataSource = new MatTableDataSource<Todo>(this.todos);
        this.isDataLoading.next(false);
      },
      error => {
        this.isDataLoading.next(false);
      }
    );
  }

  refreshTodos() {
    this.getAllTodosFromServer();
  }

  createTodoTask(todo: Todo, cb, ecb) {
    this.httpClient.post(this.baseUrl + "/tasks", todo).subscribe(
      res => {
        cb(res);
        this.refreshTodos();
      },
      error => {
        ecb(error);
      }
    );
  }

  editTodoTask(todo: Todo, cb, ecb) {
    this.httpClient.put(this.baseUrl + "/tasks/" + todo.id, todo).subscribe(
      res => {
        cb(res);
        this.refreshTodos();
      },
      error => {
        ecb(error);
      }
    );
  }

  deleteTodoTask(todo: Todo, cb, ecb) {
    this.httpClient.delete(this.baseUrl + "/tasks/" + todo.id).subscribe(
      res => {
        cb(res);
        this.refreshTodos();
      },
      error => {
        ecb(error);
      }
    );
  }

  Sort(a: any, b: any) {
    var keyA = new Date(a.taskDueDate),
      keyB = new Date(b.taskDueDate);
    // Compare the 2 dates
    if (keyA < keyB) return -1;
    if (keyA > keyB) return 1;
    return 0;
  }

  sortByHighToLowPriority() {
    var today = new Date();
    let completedTasks = this.todos.filter(todo => todo.completed);

    let pendingBufferTasks = this.todos.filter(todo => {
      var taskDueDate = new Date(todo.taskDueDate);
      return (
        (taskDueDate.getDate() == today.getDate() &&
          taskDueDate.getMonth() == today.getMonth() &&
          taskDueDate.getFullYear() == today.getFullYear() &&
          !todo.completed) ||
        (taskDueDate > today && !todo.completed)
      );
    });
    let pendingOverDueTasks = this.todos.filter(todo => {
      var taskDueDate = new Date(todo.taskDueDate);
      return (
        taskDueDate < today &&
        !todo.completed &&
        taskDueDate.getDate() != today.getDate() &&
        taskDueDate.getMonth() == today.getMonth() &&
        taskDueDate.getFullYear() == today.getFullYear()
      );
    });

    completedTasks.sort(this.Sort);
    pendingBufferTasks.sort(this.Sort);
    pendingOverDueTasks.sort(this.Sort);

    this.todos = pendingOverDueTasks
      .concat(pendingBufferTasks)
      .concat(completedTasks);
  }
}
