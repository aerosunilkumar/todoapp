import { Component, OnInit } from "@angular/core";
import { FormBuilder, Validators, FormGroup } from "@angular/forms";
import { TodoService } from "../todo-service/todo.service";

@Component({
  selector: "app-todo-create",
  templateUrl: "./todo-create.component.html",
  styleUrls: ["./todo-create.component.scss"]
})
export class TodoCreateComponent implements OnInit {
  form: FormGroup;
  private formSubmitAttempt: boolean;

  constructor(private fb: FormBuilder, private todoService: TodoService) {}

  ngOnInit() {
    this.resetForm();
  }

  resetForm() {
    this.form = this.fb.group({
      taskTitle: ["", Validators.required],
      taskDueDate: ["", Validators.required]
    });
  }

  isFieldInvalid(field: string) {
    return (
      (!this.form.get(field).valid && this.form.get(field).touched) ||
      (this.form.get(field).untouched && this.formSubmitAttempt)
    );
  }
  isloadding = false;
  onSubmit() {
    if (this.form.valid) {
      this.todoService.createTodoTask(
        this.form.value,
        successResponse => {
          this.isloadding = true;
          setTimeout(() => {
            this.resetForm();
            this.isloadding = false;
          }, 10);
        },
        error => {
          console.log("Error Handling");
        }
      );
    }
    this.formSubmitAttempt = true;
  }
}
