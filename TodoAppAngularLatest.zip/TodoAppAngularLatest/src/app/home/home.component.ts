import { Component } from "@angular/core";
import { TodoService } from "../todo-service/todo.service";

@Component({
  selector: "app-home",
  templateUrl: "./home.component.html",
  styles: []
})
export class HomeComponent {
  constructor(private todoService: TodoService) {
    this.todoService.getAllTodosFromServer();
  }
}
