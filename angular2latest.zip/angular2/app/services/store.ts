import { Date } from "angular2/src/facade/lang";

export class Todo {
  completed: boolean;
  editing: boolean;

  private _taskDueDate: string;
  get taskDueDate() {
    return this._taskDueDate;
  }
  set taskDueDate(value: string) {
    this._taskDueDate = value;
  }

  private _taskTitle: string;
  get taskTitle() {
    return this._taskTitle;
  }
  set taskTitle(value: string) {
    this._taskTitle = value.trim();
  }

  // private _title: string;
  // get title() {
  // 	return this._title;
  // }
  // set title(value: string) {
  // 	this._title = value.trim();
  // }

  constructor(taskTitle: string, taskDueDate: string) {
    this.completed = false;
    this.editing = false;
    this.taskTitle = taskTitle;
    this.taskDueDate = taskDueDate;
  }
}

export class TodoStore {
  todos: Array<Todo>;

  constructor() {
    let persistedTodos = JSON.parse(
      localStorage.getItem("angular2-todos") || "[]"
    );
    // Normalize back into classes
    this.todos = persistedTodos.map(
      (todo: {
        _taskTitle: string;
        _taskDueDate: string;
        completed: boolean;
      }) => {
        let ret = new Todo(todo._taskTitle, todo._taskDueDate);
        ret.completed = todo.completed;
        return ret;
      }
    );
    this.sortByHighToLowPriority();
  }

  private updateStore() {
    localStorage.setItem("angular2-todos", JSON.stringify(this.todos));
  }

  private getWithCompleted(completed: boolean) {
    return this.todos.filter((todo: Todo) => todo.completed === completed);
  }

  allCompleted() {
    return this.todos.length === this.getCompleted().length;
  }

  setAllTo(completed: boolean) {
    this.todos.forEach((t: Todo) => (t.completed = completed));
    this.updateStore();
    this.sortByHighToLowPriority();
  }

  removeCompleted() {
    this.todos = this.getWithCompleted(false);
    this.updateStore();
    this.sortByHighToLowPriority();
  }

  getRemaining() {
    return this.getWithCompleted(false);
  }

  getCompleted() {
    return this.getWithCompleted(true);
  }

  toggleCompletion(todo: Todo) {
    todo.completed = !todo.completed;
    this.updateStore();
    this.sortByHighToLowPriority();
  }

  remove(todo: Todo) {
    this.todos.splice(this.todos.indexOf(todo), 1);
    this.updateStore();
    this.sortByHighToLowPriority();
  }

  add(taskTitle: string, taskDueDate: string) {
    this.todos.push(new Todo(taskTitle, taskDueDate));
    this.updateStore();
    this.sortByHighToLowPriority();
  }

  Sort(a: any, b: any) {
    var keyA = new Date(a.taskDueDate),
      keyB = new Date(b.taskDueDate);
    // Compare the 2 dates
    if (keyA < keyB) return -1;
    if (keyA > keyB) return 1;
    return 0;
  }

  sortByHighToLowPriority() {
    var today = new Date();
    let completedTasks = this.todos.filter(todo => todo.completed);

    let pendingBufferTasks = this.todos.filter(todo => {
      var taskDueDate = new Date(todo.taskDueDate);
      return (
        (taskDueDate.getDate() == today.getDate() &&
          taskDueDate.getMonth() == today.getMonth() &&
          taskDueDate.getFullYear() == today.getFullYear() &&
          !todo.completed) ||
        (taskDueDate > today && !todo.completed)
      );
    });
    let pendingOverDueTasks = this.todos.filter(todo => {
      var taskDueDate = new Date(todo.taskDueDate);
      return (
        taskDueDate < today &&
        !todo.completed &&
        taskDueDate.getDate() != today.getDate() &&
        taskDueDate.getMonth() == today.getMonth() &&
        taskDueDate.getFullYear() == today.getFullYear()
      );
    });

    completedTasks.sort(this.Sort);
    pendingBufferTasks.sort(this.Sort);
    pendingOverDueTasks.sort(this.Sort);

    this.todos = pendingOverDueTasks
      .concat(pendingBufferTasks)
      .concat(completedTasks);
    this.updateStore();
  }
}
