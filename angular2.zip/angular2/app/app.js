var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("angular2/core");
var store_1 = require("./services/store");
var TodoApp = (function () {
    function TodoApp(todoStore) {
        this.newTodoText = "";
        this.username = "";
        this.password = "";
        this.userLoggedIn = false;
        this.taskDueDate = "";
        this.taskTitle = "";
        this.todoStore = todoStore;
    }
    TodoApp.prototype.checkLogin = function () {
        if (this.username == "") {
            alert("User Name is Required");
            return;
        }
        if (this.password == "") {
            alert("Password is Required");
            return;
        }
        if (this.username == this.password) {
            this.userLoggedIn = true;
        }
        else {
            this.userLoggedIn = false;
        }
    };
    TodoApp.prototype.logout = function () {
        this.userLoggedIn = false;
        this.username = "";
        this.password = "";
        return false;
    };
    TodoApp.prototype.stopEditing = function (todo, editedTitle) {
        todo.taskTitle = editedTitle;
        todo.editing = false;
    };
    TodoApp.prototype.cancelEditingTodo = function (todo) {
        todo.editing = false;
    };
    TodoApp.prototype.updateEditingTodo = function (todo, editedTitle) {
        editedTitle = editedTitle.trim();
        todo.editing = false;
        if (editedTitle.length === 0) {
            return this.todoStore.remove(todo);
        }
        todo.taskTitle = editedTitle;
    };
    TodoApp.prototype.editTodo = function (todo) {
        todo.editing = true;
    };
    TodoApp.prototype.removeCompleted = function () {
        this.todoStore.removeCompleted();
    };
    TodoApp.prototype.toggleCompletion = function (todo) {
        this.todoStore.toggleCompletion(todo);
    };
    TodoApp.prototype.remove = function (todo) {
        this.todoStore.remove(todo);
    };
    TodoApp.prototype.addTodo = function () {
        if (this.taskDueDate.trim().length) {
            if (this.taskTitle.trim().length) {
                this.todoStore.add(this.taskTitle, this.taskDueDate);
                this.newTodoText = "";
            }
        }
    };
    TodoApp.prototype.getPriorityClass = function (todo) {
        var today = new Date();
        var taskDueDate = new Date(todo.taskDueDate);
        if (todo.completed) {
            return "alert-success";
        }
        else if (taskDueDate.getDate() == today.getDate() &&
            taskDueDate.getMonth() == today.getMonth() &&
            taskDueDate.getFullYear() == today.getFullYear()) {
            return "alert-warning";
        }
        else if (taskDueDate < today) {
            return "alert-danger";
        }
        else {
            return "alert-primary";
        }
    };
    TodoApp.prototype.getTaskStatus = function (todo) {
        var today = new Date();
        var taskDueDate = new Date(todo.taskDueDate);
        if (todo.completed) {
            return "Completed";
        }
        else if (taskDueDate.getDate() == today.getDate() &&
            taskDueDate.getMonth() == today.getMonth() &&
            taskDueDate.getFullYear() == today.getFullYear()) {
            return "Medium";
        }
        else if (taskDueDate < today) {
            return "High";
        }
        else {
            return "Low";
        }
    };
    TodoApp.prototype.sortByHighToLowPriority = function () {
        this.todoStore.sortByHighToLowPriority();
    };
    TodoApp = __decorate([
        core_1.Component({
            selector: "todo-app",
            styleUrls: ["node_modules/bootstrap/dist/css/bootstrap.min.css"],
            templateUrl: "app/app.html"
        }), 
        __metadata('design:paramtypes', [store_1.TodoStore])
    ], TodoApp);
    return TodoApp;
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = TodoApp;
//# sourceMappingURL=app.js.map