var lang_1 = require("angular2/src/facade/lang");
var Todo = (function () {
    // private _title: string;
    // get title() {
    // 	return this._title;
    // }
    // set title(value: string) {
    // 	this._title = value.trim();
    // }
    function Todo(taskTitle, taskDueDate) {
        this.completed = false;
        this.editing = false;
        this.taskTitle = taskTitle;
        this.taskDueDate = taskDueDate;
    }
    Object.defineProperty(Todo.prototype, "taskDueDate", {
        get: function () {
            return this._taskDueDate;
        },
        set: function (value) {
            this._taskDueDate = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Todo.prototype, "taskTitle", {
        get: function () {
            return this._taskTitle;
        },
        set: function (value) {
            this._taskTitle = value.trim();
        },
        enumerable: true,
        configurable: true
    });
    return Todo;
})();
exports.Todo = Todo;
var TodoStore = (function () {
    function TodoStore() {
        var persistedTodos = JSON.parse(localStorage.getItem("angular2-todos") || "[]");
        // Normalize back into classes
        this.todos = persistedTodos.map(function (todo) {
            var ret = new Todo(todo._taskTitle, todo._taskDueDate);
            ret.completed = todo.completed;
            return ret;
        });
    }
    TodoStore.prototype.updateStore = function () {
        localStorage.setItem("angular2-todos", JSON.stringify(this.todos));
    };
    TodoStore.prototype.getWithCompleted = function (completed) {
        return this.todos.filter(function (todo) { return todo.completed === completed; });
    };
    TodoStore.prototype.allCompleted = function () {
        return this.todos.length === this.getCompleted().length;
    };
    TodoStore.prototype.setAllTo = function (completed) {
        this.todos.forEach(function (t) { return (t.completed = completed); });
        this.updateStore();
    };
    TodoStore.prototype.removeCompleted = function () {
        this.todos = this.getWithCompleted(false);
        this.updateStore();
    };
    TodoStore.prototype.getRemaining = function () {
        return this.getWithCompleted(false);
    };
    TodoStore.prototype.getCompleted = function () {
        return this.getWithCompleted(true);
    };
    TodoStore.prototype.toggleCompletion = function (todo) {
        todo.completed = !todo.completed;
        this.updateStore();
    };
    TodoStore.prototype.remove = function (todo) {
        this.todos.splice(this.todos.indexOf(todo), 1);
        this.updateStore();
    };
    TodoStore.prototype.add = function (taskTitle, taskDueDate) {
        this.todos.push(new Todo(taskTitle, taskDueDate));
        this.updateStore();
    };
    TodoStore.prototype.Sort = function (a, b) {
        var keyA = new lang_1.Date(a.taskDueDate), keyB = new lang_1.Date(b.taskDueDate);
        // Compare the 2 dates
        if (keyA < keyB)
            return -1;
        if (keyA > keyB)
            return 1;
        return 0;
    };
    TodoStore.prototype.sortByHighToLowPriority = function () {
        var today = new lang_1.Date();
        var completedTasks = this.todos.filter(function (todo) { return todo.completed; });
        var pendingBufferTasks = this.todos.filter(function (todo) {
            var taskDueDate = new lang_1.Date(todo.taskDueDate);
            return ((taskDueDate.getDate() == today.getDate() &&
                taskDueDate.getMonth() == today.getMonth() &&
                taskDueDate.getFullYear() == today.getFullYear() &&
                !todo.completed) ||
                (taskDueDate > today && !todo.completed));
        });
        var pendingOverDueTasks = this.todos.filter(function (todo) {
            var taskDueDate = new lang_1.Date(todo.taskDueDate);
            return (taskDueDate < today &&
                !todo.completed &&
                taskDueDate.getDate() != today.getDate() &&
                taskDueDate.getMonth() == today.getMonth() &&
                taskDueDate.getFullYear() == today.getFullYear());
        });
        completedTasks.sort(this.Sort);
        pendingBufferTasks.sort(this.Sort);
        pendingOverDueTasks.sort(this.Sort);
        this.todos = pendingOverDueTasks
            .concat(pendingBufferTasks)
            .concat(completedTasks);
    };
    return TodoStore;
})();
exports.TodoStore = TodoStore;
//# sourceMappingURL=store.js.map