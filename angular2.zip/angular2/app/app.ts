import { Component } from "angular2/core";
import { TodoStore, Todo } from "./services/store";

@Component({
  selector: "todo-app",
  styleUrls: ["node_modules/bootstrap/dist/css/bootstrap.min.css"],
  templateUrl: "app/app.html"
})
export default class TodoApp {
  todoStore: TodoStore;
  newTodoText = "";
  username = "";
  password = "";
  userLoggedIn = false;
  taskDueDate: string = "";
  taskTitle: string = "";
  constructor(todoStore: TodoStore) {
    this.todoStore = todoStore;
  }

  checkLogin() {
    if (this.username == "") {
      alert("User Name is Required");
      return;
    }

    if (this.password == "") {
      alert("Password is Required");
      return;
    }

    if (this.username == this.password) {
      this.userLoggedIn = true;
    } else {
      this.userLoggedIn = false;
    }
  }

  logout() {
    this.userLoggedIn = false;
    this.username = "";
    this.password = "";
    return false;
  }

  stopEditing(todo: Todo, editedTitle: string) {
    todo.taskTitle = editedTitle;
    todo.editing = false;
  }

  cancelEditingTodo(todo: Todo) {
    todo.editing = false;
  }

  updateEditingTodo(todo: Todo, editedTitle: string) {
    editedTitle = editedTitle.trim();
    todo.editing = false;

    if (editedTitle.length === 0) {
      return this.todoStore.remove(todo);
    }

    todo.taskTitle = editedTitle;
  }

  editTodo(todo: Todo) {
    todo.editing = true;
  }

  removeCompleted() {
    this.todoStore.removeCompleted();
  }

  toggleCompletion(todo: Todo) {
    this.todoStore.toggleCompletion(todo);
  }

  remove(todo: Todo) {
    this.todoStore.remove(todo);
  }

  addTodo() {
    if (this.taskDueDate.trim().length) {
      if (this.taskTitle.trim().length) {
        this.todoStore.add(this.taskTitle, this.taskDueDate);
        this.newTodoText = "";
      }
    }
  }

  getPriorityClass(todo: any) {
    var today = new Date();
    var taskDueDate = new Date(todo.taskDueDate);
    if (todo.completed) {
      return "alert-success";
    } else if (
      taskDueDate.getDate() == today.getDate() &&
      taskDueDate.getMonth() == today.getMonth() &&
      taskDueDate.getFullYear() == today.getFullYear()
    ) {
      return "alert-warning";
    } else if (taskDueDate < today) {
      return "alert-danger";
    } else {
      return "alert-primary";
    }
  }

  getTaskStatus(todo: any) {
    var today = new Date();
    var taskDueDate = new Date(todo.taskDueDate);
    if (todo.completed) {
      return "Completed";
    } else if (
      taskDueDate.getDate() == today.getDate() &&
      taskDueDate.getMonth() == today.getMonth() &&
      taskDueDate.getFullYear() == today.getFullYear()
    ) {
      return "Medium";
    } else if (taskDueDate < today) {
      return "High";
    } else {
      return "Low";
    }
  }

  sortByHighToLowPriority() {
    this.todoStore.sortByHighToLowPriority();
  }
}
